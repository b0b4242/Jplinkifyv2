document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");

  function setMenu(opened) {
    nav.classList.toggle("open", opened);
    toggle.setAttribute("aria-expanded", String(opened));
    toggle.setAttribute("aria-label", opened ? "Fermer le menu" : "Ouvrir le menu");
    toggle.textContent = opened ? "✕" : "☰";
  }

  if (toggle && nav) {
    toggle.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => setMenu(false)));
  }

  document.querySelectorAll("[data-year]").forEach(el => {
    el.textContent = new Date().getFullYear();
  });
});

/* --- v7 : chargement des formulaires + hors ligne --- */
document.addEventListener("DOMContentLoaded", () => {
  const track = (name, params) => { if (window.jplTrack) window.jplTrack(name, params); };

  document.querySelectorAll(".form-frame iframe").forEach(frame => {
    const box = frame.parentElement;
    const name = frame.getAttribute("title") || "formulaire";
    const noteLink = box.parentElement.querySelector(".frame-note a");
    const fallbackUrl = noteLink ? noteLink.href : frame.src.replace("?embedded=true", "");
    const state = document.createElement("div");
    state.className = "frame-state";
    state.setAttribute("role", "status");
    let timer = null;
    let shown = false;
    let broken = false;

    // Un iframe bloqué déclenche quand même « load » (page d'erreur du navigateur) :
    // on vérifie donc la connexion avec une requête « no-cors ».
    function probe() {
      if (!window.fetch) return;
      fetch(fallbackUrl, { mode: "no-cors", cache: "no-store" }).catch(failed);
    }

    function loading() {
      state.innerHTML = '<div class="spinner" aria-hidden="true"></div><p>Chargement du formulaire…</p>';
      if (!state.isConnected) box.appendChild(state);
      clearTimeout(timer);
      timer = setTimeout(failed, 12000);
    }

    function failed() {
      if (broken) return;
      broken = true;
      clearTimeout(timer);
      const offline = !navigator.onLine;
      state.innerHTML =
        "<h3>" + (offline ? "Tu n’es pas connecté à Internet" : "Le formulaire met du temps à s’afficher") + "</h3>" +
        "<p>" + (offline ? "Reconnecte-toi, puis réessaie." : "Vérifie ta connexion, puis réessaie. Tu peux aussi l’ouvrir dans une nouvelle page.") + "</p>" +
        '<div class="actions"><button type="button" class="button primary" data-retry>Réessayer</button>' +
        '<a class="button secondary" target="_blank" rel="noopener">Ouvrir dans une nouvelle page</a></div>';
      state.querySelector("a").href = fallbackUrl;
      if (!state.isConnected) box.appendChild(state);
      state.querySelector("[data-retry]").addEventListener("click", () => {
        broken = false;
        loading();
        probe();
        frame.src = frame.src;
      });
      track("formulaire_erreur", { formulaire: name, hors_ligne: offline });
    }

    frame.addEventListener("load", () => {
      if (broken) return;
      const n = parseInt(frame.getAttribute("data-n") || "0", 10);
      clearTimeout(timer);
      state.remove();
      if (!shown) {
        shown = true;
        track("formulaire_affiche", { formulaire: name });
      } else {
        // Google Forms recharge l'iframe à chaque section et après l'envoi.
        track("formulaire_etape_ou_envoi", { formulaire: name, chargement: n });
      }
    });

    if (parseInt(frame.getAttribute("data-n") || "0", 10) >= 1) {
      shown = true; // déjà chargé avant que le script démarre
    } else {
      loading();
      probe();
    }
    window.addEventListener("offline", () => { if (!shown) failed(); });
  });

  if ("serviceWorker" in navigator && location.protocol === "https:") {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }
});
