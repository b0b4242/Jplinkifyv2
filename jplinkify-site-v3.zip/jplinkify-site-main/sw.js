// Service worker JP Linkify : affiche une page claire quand il n'y a pas de connexion.
const CACHE = 'jpl-v1';
const OFFLINE = 'offline.html';
const PRE = [OFFLINE, 'assets/style.css?v=7', 'assets/main.js?v=7', 'assets/logo-mark.svg', 'assets/favicon.svg'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(PRE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  if (r.mode === 'navigate') {
    e.respondWith(fetch(r).catch(() => caches.match(OFFLINE)));
  } else if (new URL(r.url).origin === location.origin) {
    e.respondWith(fetch(r).catch(() => caches.match(r)));
  }
});
