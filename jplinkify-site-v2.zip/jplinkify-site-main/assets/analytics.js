/* JP Linkify : témoins + statistiques (Google Analytics 4), seulement après consentement. */
(function () {
  // ▼ Remplace par ton identifiant de mesure GA4 (format G-XXXXXXXXXX).
  //   Tant qu'il n'est pas remplacé, aucune bannière n'est affichée et rien n'est mesuré.
  var GA_ID = "G-XXXXXXXXXX";

  var KEY = "jpl-consent-v1";
  var enabled = false;

  function configured() { return /^G-[A-Z0-9]{6,}$/.test(GA_ID) && GA_ID !== "G-XXXXXXXXXX"; }
  function read() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(v) { try { localStorage.setItem(KEY, v); } catch (e) {} }

  function loadGA() {
    if (!configured()) return;
    window["ga-disable-" + GA_ID] = false;
    if (enabled) return;
    enabled = true;
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag("js", new Date());
    window.gtag("config", GA_ID, { allow_google_signals: false, allow_ad_personalization_signals: false });
    var s = document.createElement("script");
    s.async = true;
    s.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(GA_ID);
    document.head.appendChild(s);
  }

  function stopGA() {
    enabled = false;
    if (configured()) window["ga-disable-" + GA_ID] = true;
    var host = location.hostname;
    document.cookie.split(";").forEach(function (c) {
      var n = c.split("=")[0].trim();
      if (n === "_ga" || n.indexOf("_ga_") === 0) {
        document.cookie = n + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
        document.cookie = n + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=" + host;
        document.cookie = n + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=." + host;
      }
    });
  }

  window.jplTrack = function (name, params) {
    if (enabled && window.gtag) window.gtag("event", name, params || {});
  };

  function closeBanner() { var b = document.getElementById("cookie-banner"); if (b) b.remove(); }

  function showBanner() {
    if (document.getElementById("cookie-banner")) return;
    var b = document.createElement("div");
    b.id = "cookie-banner";
    b.className = "cookie";
    b.setAttribute("role", "dialog");
    b.setAttribute("aria-labelledby", "cookie-title");
    b.innerHTML =
      '<h2 id="cookie-title">Témoins et statistiques</h2>' +
      "<p>Avec ton accord, nous mesurons les visites avec Google Analytics pour améliorer le site. Aucune publicité. Tu peux changer d’avis en tout temps. " +
      '<a href="confidentialite.html">En savoir plus</a></p>' +
      '<div class="cookie-actions">' +
      '<button type="button" class="button" data-choice="refuse">Refuser</button>' +
      '<button type="button" class="button" data-choice="accept">Accepter</button>' +
      "</div>";
    b.addEventListener("click", function (e) {
      var c = e.target.getAttribute && e.target.getAttribute("data-choice");
      if (!c) return;
      if (c === "accept") { write("accepted"); loadGA(); } else { write("refused"); stopGA(); }
      closeBanner();
    });
    document.body.appendChild(b);
    var first = b.querySelector("button");
    if (first) first.focus({ preventScroll: true });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!configured()) return;
    document.querySelectorAll("[data-cookie-settings]").forEach(function (btn) {
      btn.hidden = false;
      btn.addEventListener("click", showBanner);
    });
    var v = read();
    if (v === "accepted") loadGA();
    else if (v !== "refused") showBanner();
  });

  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest("a");
    if (!a) return;
    var href = a.getAttribute("href") || "";
    var where = a.closest(".header") ? "entete" : a.closest(".hero") ? "accueil_haut" :
      a.closest(".cat-grid") ? "categories" : a.closest(".cta") ? "bandeau" :
      a.closest(".footer") ? "pied_de_page" : a.closest(".aside") ? "page_service" : "contenu";
    if (/(^|\/)demande\.html/.test(href)) {
      window.jplTrack("clic_faire_une_demande", { emplacement: where, page: location.pathname });
    }
    if (a.classList.contains("cat")) {
      var b = a.querySelector("b");
      window.jplTrack("clic_categorie", { categorie: b ? b.textContent : "" });
    }
    if (/docs\.google\.com\/forms/.test(href)) {
      window.jplTrack("formulaire_nouvelle_page", { page: location.pathname });
    }
  });
})();
